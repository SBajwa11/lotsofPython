README.TXT

As the python program is not integrated into the website, the satool.py script has to be run through terminal with the desired text that has to be analysed being inputted into usertweet variable. It will produce a positive or negative result. 